$(document).ready(function() {
	states_actions();
});

function states_actions() {
//		console.log('1');
	$('#country').unbind('change').change(function() {
		console.log('Country changed');
		bc = false;
//alert($(this).val());
		if (states[$(this).val()]) {
			var s = states[$(this).val()]['states'],
				html = '<select name="posted_data[state]" id="state">';
//alert(s);
			for (var x in s)
				html += '<option value="'+s[x]['code']+'"'+(s[x]['code'] == user_state ? ' selected' : '')+'>'+s[x]['state']+'</option>';

			html += '</select>';
			if ($('.admin-area').size())
				$('#state').closest('td').html('<div class="select-title">{lng[State]}</div>'+html);
			else
				$('#state').parent().html(html);

			$('#state').unbind('change').change(function() {
				user_state = $(this).val();
			});

//			alert(html);
		} else {
			if ($('.admin-area').size())
				$('#state').closest('td').html('<input type="text" name="posted_data[state]" id="state" value="'+user_state+'" /></td>');
			else
				$('#state').parent().html('<input type="text" name="posted_data[state]" id="state" value="'+user_state+'" /></td>');

			$('#state').unbind('keyup').keyup(function() {
				user_state = $(this).val();
			});

			if ($('.admin-area').size()) {
				try {
					custom_elements();
					reinitialize_mdl();
				} catch (err) {
				}
			}
		}
	});

	$('#country_checkout').unbind('change').change(function() {
		console.log('Country changed');
		bc = false;
//alert($(this).val());
		if (states[$(this).val()]) {
			var s = states[$(this).val()]['states'],
				html = '<select name="posted_data[state]" id="state_checkout">';
//alert(s);
			for (var x in s)
				html += '<option value="'+s[x]['code']+'"'+(s[x]['code'] == user_state ? ' selected' : '')+'>'+s[x]['state']+'</option>';

			html += '</select>';
			$('#state_checkout').parent().html(html);
//			alert(html);
			$('#state_checkout').unbind('change').change(function() {
				user_state = $(this).val();
			});
		} else {
			$('#state_checkout').parent().html('<input type="text" name="posted_data[state]" id="state_checkout" value="'+user_state+'" /></td>');
			$('#state_checkout').unbind('keyup').keyup(function() {
				user_state = $(this).val();
			});
		}

		try {
			checkout_changes();
		} catch (err) {
		}
	});

	setTimeout(function() {
		$('#country_checkout').trigger('change');
		$('#country').trigger('change');
	}, 100);
}